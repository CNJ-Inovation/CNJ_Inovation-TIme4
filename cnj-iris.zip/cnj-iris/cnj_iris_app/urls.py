from django.urls import path

from cnj_iris_app import views


# import DfCreate, DfDetail, get_fiscalizado, get_fiscal

app_name = "cnj_iris_app"
urlpatterns = [
     path('', views.DadosBasicosFormView.as_view(),
          name='index'),
     path('dados-basicos', views.DadosBasicosFormView.as_view(),
          name='dados-basicos'),
]
