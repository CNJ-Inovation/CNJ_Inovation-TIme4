import json
import os

import pandas as pd

from django.shortcuts import render
from django.urls import reverse_lazy
from django.views.generic.edit import FormView
from django.views.generic.detail import DetailView
from django.views.generic.list import ListView

from cnj_iris_app.forms import DadosBasicosForm

# Create your views here.


class DadosBasicosFormView(FormView):
    template_name = 'cnj_iris_app/dadosbasicos_form.html'
    form_class = DadosBasicosForm
    success_url = reverse_lazy('cnj_iris_app:dados-basicos')

    def form_valid(self, form):
        if form.cleaned_data["uploaded_file"]:
            f = form.cleaned_data["uploaded_file"]
            with open("upload.json", "wb") as output:
                output.write(f.read())
            os.chdir("/Users/ylaguardia/code/CNJ_Inovation-TIme4/")
            os.system("python3 Read.py")

        return render(self.request, self.template_name, context={
            'data': form.cleaned_data,
            'is_result': True,
            'form': form
            })

class DadosBasicosDetailView(DetailView):
    template_name = 'cnj_iris_app/processo_detail.html'
