from django.apps import AppConfig


class CnjIrisAppConfig(AppConfig):
    name = 'cnj_iris_app'
