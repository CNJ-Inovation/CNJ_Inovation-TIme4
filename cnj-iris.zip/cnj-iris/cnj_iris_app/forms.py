from django import forms

from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit, Layout, Row, Column
from crispy_forms.layout import Fieldset, Div, HTML, ButtonHolder, Field, Button
from crispy_forms.bootstrap import InlineCheckboxes


class DadosBasicosForm(forms.Form):

    # dadosBasicos.assunto:
    principal = forms.BooleanField(required=False)

    # dadosBasicos.assunto.codigoNacional
    codigoNacional = forms.IntegerField(label="Assunto nacional: campo codigoNacional", required=False)

    # dadosBasicos.assunto.assuntoLocal
    codigoAssunto = forms.IntegerField(label="Assunto local: campo codigoAssunto", required=False)
    codigoPaiNacional = forms.IntegerField(label="Assunto local: campo codigoPaiNacional", required=False)

    # dadosBasicos.classeProcessual
    classeProcessual = forms.IntegerField(label="Classe Processual", required=False)
    # dadosBasicos.competencia
    competencia = forms.IntegerField(label="Competência", required=False)

    # dadosBasicos.numero
    numero = forms.CharField(max_length=20, required=False)

    # NNNNNNN-DD.AAAA.J.TR.OOOO
    # Numeracao sequencial anual
    nr_nn = forms.CharField(label="Campo NNNNNNN", required=False)  # help_text="número seqüencial do processo por unidade de origem (OOOO), a ser reiniciado a cada ano")
    # Dv
    nr_dd = forms.CharField(label="DD", required=False)  # required=False, help_text="Dígito verificador, cujo cálculo de verificação deve ser efetuado pela aplicação de algoritmo público (Anexo VIII da Resolução Nº 65 de 16/12/2008)")
    # Ano
    nr_aa = forms.CharField(label="AAAA", required=False)  # required=False, help_text="Identifica o ano do ajuizamento do processo")
    # segmento do Poder Judiciário (STF, STJ, JT, JF etc). Possiveis: 1 a 9
    nr_j = forms.CharField(label="J", required=False)  # help_text="Valores possíveis de 1 a 9, sendo: Supremo Tribunal Federal: 1 (um); Conselho Nacional de Justiça: 2 (dois); Superior Tribunal de Justiça: 3 (três); Justiça Federal: 4 (quatro); Justiça do Trabalho: 5 (cinco); Justiça Eleitoral: 6 (seis); Justiça Militar da União: 7 (sete); Justiça dos Estados e do Distrito Federal e Territórios: 8 (oito); Justiça Militar Estadual: 9 (nove).")
    # tribunal (Ex: TRE do 1 ao 27, CJF 90)
    nr_tr = forms.CharField(label="TR", required=False)  # help_text="Tribunal do respectivo segmento do Poder Judiciário e, na Justiça Militar da União, a Circunscrição Judiciária")
    # unidade (Subseção da JF, Vara da JT etc). Possiveis: 0001 a 8999
    # tbm: 0000 se originario de tribunal. Inicio 9 se orig de Turm. Rec.
    nr_oo = forms.CharField(label="OOOO", required=False) # help_text="Unidade de origem do processo (Vara, Subseção Judiciária etc)")

    uploaded_file = forms.FileField(label="Upload de Arquivo:", required=False)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # ++ Helper
        self.helper = FormHelper()
        self.helper.form_class = 'needs-validation'

        self.helper.layout = Layout(
            Fieldset(
                'Dados do processo:',
                # Fieldset(
                # "Numeração única:",
                Div(
                    Div(Field('nr_nn', css_class="form-control"), css_class="col-4"),
                    Div(Field('nr_dd', css_class="form-control"), css_class="col-1"),
                    Div(Field('nr_aa', css_class="form-control"), css_class="col-2"),
                    Div(Field('nr_j', css_class="form-control"), css_class="col-1"),
                    Div(Field('nr_tr', css_class="form-control"), css_class="col-1"),
                    Div(Field('nr_oo', css_class="form-control"), css_class="col-3"),
                    css_class="form-group form-row"),

                # ),
                Div(
                Div(
                    Field('competencia', css_class="form-control"), css_class="col-sm-6"),
                    Div(Field('classeProcessual', css_class="form-control"), css_class="col-sm-6"),
                css_class="form-group form-row"),

                # Div(
                Div(
                    HTML("""
                    <div class="col-sm-6 text-center"> <div id="div_id_principal" class="control-group"> <div class="controls"> <label for="id_principal" class="checkbox ">
                        Assunto Principal?
                    </label></div><input type="checkbox" name="principal" class="checkboxinput" id="id_principal">  </div> </div>"""),
                    Div(Field('codigoNacional', css_class="form-control"), css_class="col-sm-6"),
                    css_class="form-group form-row"),
                Div(
                    Div(Field('codigoAssunto', css_class="form-control"), css_class="col-sm-6"),
                    Div(Field('codigoPaiNacional', css_class="form-control"), css_class="col-sm-6"),
                    css_class="form-group form-row"),

                    Field(
                    'uploaded_file', css_class="form-control my-3"),
                ButtonHolder(

                    Submit(
                        'submit', 'Enviar',
                        css_class="btn btn-lg btn-info font-weight-bold m-2 my-4"
                    ),

                    css_class="row justify-content-center my-3"
                ),
                css_class='my-3 p-4 d-flex flex-column align-self-center mx-auto', style="width: 85%"
           ),
        )