import datetime as dt
from django.db import models

# Create your models here.


class Processo(models.Model):
    pass
    # def timestamp_milli():
    # """Retorna timestamp deste momento em millisegundos"""
    #     # timestamp em segundos
    #     timestamp = dt.datetime.now().timestamp()
    #     # em milli:
    #     milli = int(timestamp * 1000)
    #     return milli

    # millisInsercao = models.CharField("millisInsercao", max_length="16",
    #                                   primary_key=True)
    # grau =
    # siglaTribunal
    # dadosBasicos
    #     dadosBasicos.numero
    #     dadosBasicos.outrosnumeros
    #     dadosBasicos.competencia
    #     dadosBasicos.classeProcessual
    #     dadosBasicos.codigoLocalidade
    #     dadosBasicos.nivelSigilo
    #     dadosBasicos.intervencaoMP
    #     dadosBasicos.tamanhoProcesso
    #     dadosBasicos.dataAjuizamento
    #     dadosBasicos.procEl
    #     dadosBasicos.dscSistema
    #     dadosBasicos.processoVinculado
    #     dadosBasicos.valorCausa

    #     dadosBasicos.relacaoIncidental
    #     dadosBasicos.prioridade
    #     dadosBasicos.orgaoJulgador
    #         dadosBasicos.orgaoJulgador.codigoOrgao
    #         dadosBasicos.orgaoJulgador.codigoMunicipioIBGE
    #         dadosBasicos.orgaoJulgador.nomeOrgao

    #     dadosBasicos.assunto
    #         dadosBasicos.assunto.principal
    #         dadosBasicos.assunto.codigoNacional
    #         ou
    #         dadosBasicos.assunto.assuntoLocal
    #             dadosBasicos.assunto.assuntoLocal.codigoAssunto
    #             dadosBasicos.assunto.assuntoLocal.codigoPaiNacional
    #             dadosBasicos.assunto.assuntoLocal.descricao
    # movimento

    # Classe
    # Assunto
    # Movimento
